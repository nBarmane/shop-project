<?php

Route::get('/', function () {
    return view('index');
});

Route::prefix('user')->group(function () {

    Route::post('signUp','UserController@register');

    Route::post('signIn','UserController@login');
    
    Route::get('getAll','UserController@getAllUsers');
});

Route::prefix('shop')->group(function () {
    
    Route::post('save','ShopController@save');
    
    Route::get('getAllShops','ShopController@getAll');
});

Route::prefix('preferredShops')->group(function () {
    
    Route::get('get/{user_id}','PreferredShopController@getAll');
    
    Route::post('save','PreferredShopController@save');
    
    Route::delete('delete/{preferredShop_id}','PreferredShopController@delete');
});

Route::prefix('dislikedShops')->group(function () {
    
    Route::get('get/{user_id}','DislikedShopController@getAll');
    
    Route::post('save','DislikedShopController@save');
    
    Route::delete('delete/{dislikedShop_id}','DislikedShopController@delete');
});