<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use App\PreferredShop;

class PreferredShopController extends Controller
{
    function getAll($user_id) {
        $user = User::find($user_id);
    	return $user->preferredShops;
    }

    function save(Request $request) {
    	$preferredShop = new PreferredShop();
    	$preferredShop->user_id = $request->user_id;
    	$preferredShop->shop_id = $request->shop_id;

        $preferredShop->save();

    	return Response()->json([
    		"message_type"=> "success",
    		"message"=> "The shop has been added to your preferred shops!",
            "preferredShop"=> $preferredShop
    	]);
    }

    function delete($preferredShop_id) {
    	$preferredShop = PreferredShop::find($preferredShop_id);
    	$preferredShop->delete();

    	return Response()->json([
    		"message_type"=> "success",
    		"message"=> "The shop has been removed from your preferred shops!"
    	]);
    }
}
