<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    function register(Request $request) {
        $request->validate([
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
            'password_confirmation' => 'same:password',
            'x' => 'required|regex:/^-{0,1}\d+(\.\d+)?$/',
            'y' => 'required|regex:/^-{0,1}\d+(\.\d+)?$/'
        ]);

        $user = new User();
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->x = $request->x;
        $user->y = $request->y;

        $user->save();

        return Response()->json([
            "message_type"=> "success",
            "message"=> "You're registred, to continue please sign in!",
        ]);
    }

    function login(Request $request) {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $user = DB::table('users')
            ->where('email', $request->email)
            ->first();

        if($user!==null) {
            if (Hash::check($request->password, $user->password)){
                return Response()->json([
                    "message_type"=> "success",
                    "message"=> "You're logged in!",
                    "user"=> $user
                    ]);
            }
        }

        return Response()->json([
            "message_type"=> "error",
            "message"=> "Your credentials don't match our records!",
        ]);
    }

    function getAllUsers() {
        return DB::table("users")->get();
    }
}
