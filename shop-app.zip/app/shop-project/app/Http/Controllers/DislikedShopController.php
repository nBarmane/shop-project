<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\DislikedShop;
use App\User;

class DislikedShopController extends Controller
{
    function getAll($user_id) {
    	$user = User::find($user_id);
    	return $user->dislikedShops;
    }

    function save(Request $request) {
    	$dislikedShop = new DislikedShop();
    	$dislikedShop->user_id = $request->user_id;
    	$dislikedShop->shop_id = $request->shop_id;

        $dislikedShop->save();

    	return Response()->json([
    		"message_type"=> "success",
    		"message"=> "The shop has been added to your preferred shops!",
            "dislikedShop"=> $dislikedShop
    	]);
    }

    function delete($preferredShop_id) {
    	$disliked_shop = DislikedShop::find($dislikedShop_id);
    	$disliked_shop->delete();

    	return Response()->json([
    		"message_type"=> "success",
    		"message"=> "The shop will be shown in your nearby shops list!"

    	]);
    }
}
