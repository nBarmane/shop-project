<?php

namespace App\Http\Controllers;

use App\Shop;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ShopController extends Controller
{
    function save(Request $request) {
    	$shop = new Shop();
    	$shop->shop_name = $request->shop_name;
    	$shop->x = $request->x;
    	$shop->y = $request->y;

    	$shop->save();

    	return Response()->json([
    		"message"=> "The shop has been saved successfully!"
    	]);
    }

    function getAll() {
    	return DB::table("shops")->get();
    }
}
