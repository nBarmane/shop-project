<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    public function preferredShops(){
        return $this->hasMany('App\PreferredShop');
    }

    public function dislikedShops() {
        return $this->hasMany('App\DislikedShop');
    }

}
