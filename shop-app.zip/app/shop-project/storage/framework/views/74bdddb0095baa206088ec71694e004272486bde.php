<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/my-style.css')); ?>">

    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <title>ENSA Shop</title>
</head>
<body onload="init()">

    <div class="container-fluid">
        <div class="row justify-content-center mt-2" id="root">
            <!-- the content is loaded here! -->
        </div>
    </div>

</body>

<script src="<?php echo e(asset('js/lib/jquery.min.js')); ?>" ></script>
<script src="<?php echo e(asset('js/lib/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/lib/bootstrap.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/ajax-config.js')); ?>"></script>
<script src="<?php echo e(asset('js/auth-requests.js')); ?>"></script>
<script src="<?php echo e(asset('js/shop-requests.js')); ?>"></script>
<script src="<?php echo e(asset('js/authentication.js')); ?>"></script>
<script src="<?php echo e(asset('js/shops.js')); ?>"></script>

</html>