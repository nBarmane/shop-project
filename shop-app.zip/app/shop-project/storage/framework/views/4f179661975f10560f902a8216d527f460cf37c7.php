<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    <title>ENSA Shop</title>
</head>
<body>

    <div class="container-fluid">
        <div class="container">
            <div class="row justify-content-center" id="root">
                <div class="col-md-12">
                    <div class="row mb-4">
                        <input id="email_1" type="text" />
                        <input id="password_1" type="password" />
                        <input id="password_confirmation" type="password" />

                        <button onclick="sign_up()">Sign Up</button>
                    </div>
                    <div class="row">
                        <input id="email_2" type="text" />
                        <input id="password_2" type="password" />

                        <button onclick="login()">Login</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>" ></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/ajax-config.js')); ?>"></script>
<script src="<?php echo e(asset('js/my-script.js')); ?>"></script>

</html>