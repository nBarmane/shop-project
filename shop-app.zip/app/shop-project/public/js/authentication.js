var user;

var sign_in_form_elements = [
    {label:"Email address", type:"text", id: "email"},
    {label:"Password", type:"password", id: "password"}
];

var sign_up_form_elements = [
    {label:"Email address", type:"text", id: "email"},
    {label:"Password", type:"password", id: "password"},
    {label:"Password confirmation", type:"password", id: "password_confirmation"},
    {label:"X position", type:"text", id: "x"},
    {label:"Y position", type:"text", id: "y"},
];

function init() {
    user = sessionStorage.getItem("user");

    if (user == null) {
        showSignInForm();
    }
    else {
        user = JSON.parse(user);
        
        displayNavbar();
        
        getLists(); // fetch lists of all shop types from DB
        
        loadNearbyShops();
    }
}

function showSignInForm() {
    let root = document.getElementById("root");
    root.innerHTML = "";
    root.appendChild(buildForm("Sign in"));

    hideMsgs();
}

function showSignUpForm() {
    let root = document.getElementById("root");
    root.innerHTML = "";
    root.appendChild(buildForm("Sign up"));
    
    hideMsgs();
}

function buildForm(action) {
    let column = document.createElement("div");
    column.classList.add("col-md-5");
    
    let signFunction = (action=="Sign in") ? "signInRequest(event)" : "signUpRequest(event)";

    let form = document.createElement("form");
    form.setAttribute("onsubmit", signFunction);
    form.classList.add("form");

    let form_elements = (action=="Sign in") ? sign_in_form_elements : sign_up_form_elements;

    form_elements.forEach( function(form_element) {
        form.appendChild(buildFormElement(form_element));
    });

    var title = (action=="Sign in") ? "Login" : "Register";

    form.appendChild(buildSubmitRow(title));
    
    let card = buildCard(action, form);

    column.appendChild(card);

    return column;
}

function buildCard(title, body) {
    let card = document.createElement("div");
    card.classList.add("card");

    let card_header = document.createElement("div");
    card_header.classList.add("card-header");
    card_header.innerHTML = title;

    let card_body = document.createElement("div");
    card_body.classList.add("card-body");

    let row_msgs = document.createElement("div");
    row_msgs.classList.add("row");

    let col_msgs = document.createElement("div");
    col_msgs.classList.add("col-md-12");

    let msgs = document.createElement("div");
    msgs.classList.add("alert");
    msgs.classList.add("pb-2");
    msgs.setAttribute("id", "div-msgs");
    msgs.setAttribute("role", "alert");

    col_msgs.appendChild(msgs);
    row_msgs.appendChild(col_msgs);

    card_body.appendChild(row_msgs);

    card_body.appendChild(body);

    card.appendChild(card_header);
    card.appendChild(card_body);

    return card;
}

function buildFormElement(form_element) {
    let row = document.createElement("div");
    row.classList.add("row");
    row.classList.add("form-group");

    let column1 = document.createElement("div");
    column1.classList.add("col-md-5");

    let column2 = document.createElement("div");
    column2.classList.add("col-md-7");

    let label = document.createElement("label");
    label.setAttribute("for", form_element.id);
    label.innerHTML = form_element.label;

    let input_group = document.createElement("div");
    input_group.classList.add("input-group");
    input_group.classList.add("input-group-sm");

    let input = document.createElement("input");
    input.classList.add("form-control");
    input.setAttribute("type", form_element.type);
    input.setAttribute("id", form_element.id);

    input_group.appendChild(input);
    
    column1.appendChild(label);
    column2.appendChild(input_group);

    row.appendChild(column1);    
    row.appendChild(column2);    

    return row;
}

function buildSubmitRow(label) {
    let row = document.createElement("div");
    row.classList.add("row");
    row.classList.add("form-group");

    let column1 = document.createElement("div");
    column1.classList.add("col-md-7");
    column1.classList.add("offset-md-5");

    let link = document.createElement("label");
    link.classList.add("text-primary");
    link.classList.add("reverse-form");
    link.innerHTML = (label=="Login") ? "You don't have an account?" : "Already registred?";
    link.setAttribute("onClick", (label=="Login") ? "showSignUpForm()" : "showSignInForm()");

    let column2 = document.createElement("div");
    column2.classList.add("col-md-7");
    column2.classList.add("offset-md-5");

    let btn = document.createElement("button");
    btn.classList.add("btn");
    btn.classList.add((label=="Login") ? "btn-primary" : "btn-success");
    btn.classList.add("form-control");
    btn.setAttribute("type", "submit");
    btn.innerHTML = label;

    column1.appendChild(link);
    column2.appendChild(btn);

    row.appendChild(column1);
    row.appendChild(column2);

    return row;
}

function displayMessage(content, type) {
    let div_msgs = document.getElementById("div-msgs");
    div_msgs.classList.remove("alert-success", "alert-danger");
    div_msgs.classList.add(type);

    div_msgs.innerHTML = "";

    div_msgs.appendChild(content);
    
    div_msgs.style.display = "block";
}

function hideMsgs() {
    let div_msgs = document.getElementById("div-msgs");
    div_msgs.innerHTML = "";
    div_msgs.style.display = "none";
}

function logout() {
    sessionStorage.clear();

    user = null;

    shops=[];
    preferredShops=[];
    dislikedShops=[];

    preferredShopsIds = [];

    displayNearby = true;
    
    init();
}