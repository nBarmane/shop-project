function getAllShops() {
    $.ajax({
        url: "/shop/getAllShops",
        type: "GET",
        dataType: "json",
        data: {},
        async: false,
        complete: function(data) {
            shops = data.responseJSON;
        }
    });
}

function getPreferredShops() {
    $.ajax({
        url: "/preferredShops/get/"+user.id,
        type: "GET",
        dataType: "json",
        data: {},
        async: false,
        complete: function(data) {
            preferredShops = data.responseJSON;
        }
    });
}

function getDislikedShops() {
    $.ajax({
        url: "/dislikedShops/get/"+user.id,
        type: "GET",
        dataType: "json",
        data: {},
        async: false,
        complete: function(data) {
            dislikedShops = data.responseJSON;
        }
    });
}

/*
function saveShop() {
    $.ajax({
        url: "/shop/save",
        type: "POST",
        dataType: "json",
        data: {
            shop_name: "Lacoste",
            x: 27,
            y: 19
        },
        success: function(data) {
            //console.log(data.message);
        }
    });
}
*/

function savePreferredShop(shop_id) {
    $.ajax({
        url: "/preferredShops/save",
        type: "POST",
        dataType: "json",
        data: {
            shop_id: shop_id,
            user_id: user.id
        },
        success: function(data) {
            preferredShops.push(data.preferredShop);
            //console.log(data.message);
        }
    });
}

function deletePreferredShop(preferredShop_id) {
    $.ajax({
        url: "/preferredShops/delete/"+preferredShop_id,
        type: "DELETE",
        dataType: "json",
        data: {},
        success: function(data) {
            //console.log(data.message);
        }
    });
}

