function signInRequest(e) {
    hideMsgs();

    e.preventDefault();
    let payload = {
        email: $("#email").val(),
        password: $("#password").val()
    };

    $.ajax({
        url: "/user/signIn",
        type: "POST",
        dataType: "json",
        data: payload,
        success: function(data) {
            if(data.message_type == "success") {
                sessionStorage.setItem("user", JSON.stringify(data.user));
                init();
            }
            else if(data.message_type == "error") {
                let text_node = document.createTextNode(data.message);
                let alert_type = (data.message_type == "success") ? "alert-success" : "alert-danger";

                displayMessage(text_node, alert_type);
            }
        },
        error: function(data) {
            let errors_array = Object.values(data.responseJSON.errors);
            let text_node = document.createTextNode(errors_array[0][0]);  // retreive the first error
            displayMessage(text_node, "alert-danger");
        }
    });
}

function signUpRequest(e) {
    hideMsgs();

    e.preventDefault();
    let payload = {
        email: $("#email").val(),
        password: $("#password").val(),
        password_confirmation: $("#password_confirmation").val(),
        x: $("#x").val(),
        y: $("#y").val()
    };

    $.ajax({
        url: "/user/signUp",
        type: "POST",
        dataType: "json",
        data: payload,
        success: function(data) {
            if(data.message_type == "success")
                showSignInForm();

            let alert_type = (data.message_type == "success") ? "alert-success" : "alert-danger";

            let text_node = document.createTextNode(data.message);
            displayMessage(text_node, alert_type);
        },
        error: function(data) {
            let errors_array = Object.values(data.responseJSON.errors);
            let text_node = document.createTextNode(errors_array[0][0]);  // retreive the first error
            displayMessage(text_node, "alert-danger");
        }
    });
}