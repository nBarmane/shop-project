var shops=[];
var preferredShops=[];
var dislikedShops=[];

var preferredShopsIds = [];

var displayNearby = true;

function displayNavbar() {
    let root_div = document.getElementById("root");

    let content = document.createElement("div");
    content.classList.add("col-md-9");
    content.setAttribute("id", "root-content");

    let navbarRow = buildNavbarRow();

    content.appendChild(navbarRow);

    let shop_list = document.createElement("div");
    shop_list.classList.add("row", "pl-5", "mt-2");
    shop_list.setAttribute("id", "shop-list");

    content.appendChild(shop_list);

    root_div.innerHTML = "";
    root_div.appendChild(content);
}

function buildNavbarRow() {
    let row = document.createElement("row");
    row.classList.add("row");

    let navbar = document.createElement("div");
    navbar.classList.add("col-md-12");

    let shopsMenuItems = document.createElement("div");
    shopsMenuItems.classList.add("text-primary");
    shopsMenuItems.classList.add("float-left");
    shopsMenuItems.style.marginTop = "8px";

    let nearbyShopsItem = document.createElement("label");
    nearbyShopsItem.classList.add("mr-4");
    nearbyShopsItem.setAttribute("id", "nearbyShops");
    nearbyShopsItem.innerHTML = "Nearby shops";

    let preferredShopsItem = document.createElement("label");
    preferredShopsItem.classList.add("item-cursor");
    preferredShopsItem.setAttribute("onclick", "loadPreferredShops(); toggleProperties()");
    preferredShopsItem.setAttribute("id", "preferredShops");
    preferredShopsItem.innerHTML = "Preferred shops";

    let user_div = document.createElement("div");
    user_div.classList.add("float-right", "user-div");

    let a = document.createElement("a");
    a.classList.add("nav-link", "dropdown-toggle", "user-email");
    a.setAttribute("id", "dropdown-menu");
    a.setAttribute("role", "button");
    a.setAttribute("data-toggle", "dropdown");
    a.setAttribute("aria-haspopup", "true");
    a.setAttribute("aria-expanded", "false");
    a.innerHTML = user.email;

    let dropdown_menu = document.createElement("div");
    dropdown_menu.classList.add("dropdown-menu");
    dropdown_menu.setAttribute("aria-labelledby", "dropdown-menu");

    let logout = document.createElement("a");
    logout.classList.add("dropdown-item");
    logout.setAttribute("onClick", "logout()");
    logout.innerHTML = "Logout";

    dropdown_menu.appendChild(logout);
    a.appendChild(dropdown_menu);
    user_div.appendChild(a);

    shopsMenuItems.appendChild(nearbyShopsItem);
    shopsMenuItems.appendChild(preferredShopsItem);

    navbar.appendChild(shopsMenuItems);
    navbar.appendChild(user_div);

    row.appendChild(navbar);

    return row;
}

function toggleProperties() {
    displayNearby = !displayNearby;

    let near_label = document.getElementById("nearbyShops");
    let pref_label = document.getElementById("preferredShops");

    near_label.classList.toggle("item-cursor");

    pref_label.classList.toggle("item-cursor");

    if(displayNearby==true) {
        near_label.removeAttribute("onclick");
        pref_label.setAttribute("onclick", "loadPreferredShops(); toggleProperties()");
    }
    else {
        near_label.setAttribute("onclick", "loadNearbyShops(); toggleProperties()");
        pref_label.removeAttribute("onclick");
    }
}

function getLists() {
    getAllShops();
    getPreferredShops();
    getDislikedShops();

    preferredShops.forEach( function(shop) {
        preferredShopsIds.push(shop.shop_id);
    });
}

function loadNearbyShops() {
    let shop_list = document.getElementById("shop-list");
    shop_list.innerHTML = "";

    shops.forEach( function(shop) {
        if(preferredShopsIds.indexOf(shop.id)!=-1)
            return;

        let col = document.createElement("div");
        col.classList.add("col-md-3", "mx-4", "my-2");
        col.setAttribute("id", "shop_"+shop.id);

        let card = document.createElement("div");
        card.classList.add("card", "px-2");
        card.setAttribute("style", "width: 250px; height: 260px;")

        let img = document.createElement("img");
        img.classList.add("card-img-top", "mb-2");
        img.setAttribute("style", "height: 170px;");
        img.setAttribute("src", "storage/shop_images/"+shop.id+".png");

        let card_body = document.createElement("div");
        card_body.classList.add("card-body", "p-0");

        let title = document.createElement("h4");
        title.classList.add("card-title");
        title.innerHTML = shop.shop_name;

        let likeBtn = document.createElement("button");
        likeBtn.classList.add("btn", "btn-sm", "btn-success");
        likeBtn.setAttribute("onclick", "like_shop("+shop.id+")");
        likeBtn.innerHTML = "Like";

        let dislikeBtn = document.createElement("button");
        dislikeBtn.classList.add("btn", "btn-sm", "btn-danger", "ml-2");
        //dislikeBtn.setAttribute("onclick", "dislike_shop("+shop.id+")");
        dislikeBtn.setAttribute("disabled","true");
        dislikeBtn.innerHTML = "Dislike";

        card_body.appendChild(title);
        card_body.appendChild(likeBtn);
        card_body.appendChild(dislikeBtn);

        card.appendChild(img);
        card.appendChild(card_body);

        col.appendChild(card);

        shop_list.appendChild(col);
    });
}

function loadPreferredShops() {
    let shop_list = document.getElementById("shop-list");
    shop_list.innerHTML = "";

    preferredShops.forEach( function(shop) {
        let col = document.createElement("div");
        col.classList.add("col-md-3", "mx-4", "my-2");
        col.setAttribute("id", "shop_"+shop.id);

        let card = document.createElement("div");
        card.classList.add("card", "px-2");
        card.setAttribute("style", "width: 250px; height: 260px;")

        let img = document.createElement("img");
        img.classList.add("card-img-top", "mb-2");
        img.setAttribute("style", "height: 170px;");
        img.setAttribute("src", "storage/shop_images/"+shop.shop_id+".png");

        let card_body = document.createElement("div");
        card_body.classList.add("card-body", "p-0");

        let title = document.createElement("h4");
        title.classList.add("card-title");
        let shop_name;
        shops.forEach(function(current) {
            if(current.id==shop.shop_id) {
                shop_name=current.shop_name;
            }
        });
        title.innerHTML = shop_name;

        let removeBtn = document.createElement("button");
        removeBtn.classList.add("btn", "btn-sm", "btn-danger");
        removeBtn.setAttribute("onclick", "remove_from_preferred("+shop.id+","+shop.shop_id+")");
        removeBtn.innerHTML = "Remove";

        card_body.appendChild(title);
        card_body.appendChild(removeBtn);

        card.appendChild(img);
        card.appendChild(card_body);

        col.appendChild(card);

        shop_list.appendChild(col);
    });
}

function like_shop(shop_id) {
    savePreferredShop(shop_id);

    let shop_column = document.getElementById("shop_"+shop_id);
    shop_column.parentNode.removeChild(shop_column);

    preferredShopsIds.push(shop_id);
}

function remove_from_preferred(preferredShop_id, shop_id) {
    deletePreferredShop(preferredShop_id);

    let shop_column = document.getElementById("shop_"+preferredShop_id);
    shop_column.parentNode.removeChild(shop_column);

    let index = preferredShopsIds.indexOf(shop_id);
    preferredShopsIds.splice(index, 1);

    preferredShops.forEach( function(preferredShop, index) {
        if(preferredShop.id==preferredShop_id)
            preferredShops.splice(index, 1);
    });
}

function sortShopsList() {
    shops.forEach( function(shop) {
        shop.distanceToUser = Math.sqrt( Math.pow((shop.x-user.x), 2), Math.pow((shop.y-user.y), 2));
    });

    shops.sort( function(shop1, shop2) {
        return shop1.distanceToUser - shop2.distanceToUser;
    });
}