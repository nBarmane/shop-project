-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  Dim 16 déc. 2018 à 13:36
-- Version du serveur :  10.1.29-MariaDB
-- Version de PHP :  7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `shop_project`
--

-- --------------------------------------------------------

--
-- Structure de la table `disliked_shops`
--

CREATE TABLE `disliked_shops` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `shop_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2018_12_13_065653_create_shops_table', 1),
(3, '2018_12_13_070224_create_preferred_shops_table', 1),
(4, '2018_12_13_070552_create_disliked_shops_table', 1),
(5, '2018_12_13_070638_add_foreign_keys_to_preferred_shops_table', 1),
(6, '2018_12_13_070956_add_foreign_keys_to_disliked_shops_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `preferred_shops`
--

CREATE TABLE `preferred_shops` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `shop_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `shops`
--

CREATE TABLE `shops` (
  `id` int(10) UNSIGNED NOT NULL,
  `shop_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `x` double NOT NULL,
  `y` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `shops`
--

INSERT INTO `shops` (`id`, `shop_name`, `x`, `y`, `created_at`, `updated_at`) VALUES
(1, 'Nike', 20, 17, '2018-12-15 19:27:04', '2018-12-15 19:27:04'),
(2, 'Adidas', 18, 19, '2018-12-15 19:28:44', '2018-12-15 19:28:44'),
(3, 'Puma', 33, 47, '2018-12-16 00:52:17', '2018-12-16 00:52:17'),
(4, 'Reebok', 17, 22, '2018-12-16 01:20:46', '2018-12-16 01:20:46'),
(5, 'Lacoste', 27, 19, '2018-12-16 11:19:46', '2018-12-16 11:19:46');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `x` double NOT NULL,
  `y` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `x`, `y`, `created_at`, `updated_at`) VALUES
(1, 'nouamane@gmail.com', '$2y$10$WAcQs0eawV7wknx8B5Ncee3258rohMv4/eqsAChxuz6/Ho7tHh/gK', 14, -414.11, '2018-12-15 09:54:36', '2018-12-15 09:54:36'),
(2, 'adnan@gmail.com', '$2y$10$D1sEyOCafdDen3P0Lt.j5Ou/OyhQzW0zfnL/VOqsmvLbtsmEhirf6', 5.33, 10.1, '2018-12-15 13:22:22', '2018-12-15 13:22:22'),
(3, 'amine@gmail.com', '$2y$10$GxC9MbpytadZhUhY7Yebte30kC/uZhWH2PeQ29Oiyq94/21Faj1gS', 12.441, 30.5541, '2018-12-15 14:44:55', '2018-12-15 14:44:55');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `disliked_shops`
--
ALTER TABLE `disliked_shops`
  ADD PRIMARY KEY (`id`),
  ADD KEY `disliked_shops_user_id_foreign` (`user_id`),
  ADD KEY `disliked_shops_shop_id_foreign` (`shop_id`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `preferred_shops`
--
ALTER TABLE `preferred_shops`
  ADD PRIMARY KEY (`id`),
  ADD KEY `preferred_shops_user_id_foreign` (`user_id`),
  ADD KEY `preferred_shops_shop_id_foreign` (`shop_id`);

--
-- Index pour la table `shops`
--
ALTER TABLE `shops`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `shops_shop_name_unique` (`shop_name`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `disliked_shops`
--
ALTER TABLE `disliked_shops`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `preferred_shops`
--
ALTER TABLE `preferred_shops`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT pour la table `shops`
--
ALTER TABLE `shops`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `disliked_shops`
--
ALTER TABLE `disliked_shops`
  ADD CONSTRAINT `disliked_shops_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`),
  ADD CONSTRAINT `disliked_shops_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `preferred_shops`
--
ALTER TABLE `preferred_shops`
  ADD CONSTRAINT `preferred_shops_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`),
  ADD CONSTRAINT `preferred_shops_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
